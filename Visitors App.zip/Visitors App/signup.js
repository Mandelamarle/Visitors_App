if (condition) {
    statement
}

else if (anotherCondition){
    statement
}
